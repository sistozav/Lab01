#include <stdlib.h>
#include <stdio.h>

int main()

{ 
printf("Running test.c program\n");
}
